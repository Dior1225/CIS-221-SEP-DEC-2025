CREATE TABLE IF NOT EXISTS inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_name TEXT,
    total_stock INTEGER,
    sold INTEGER DEFAULT 0,
    price REAL
);

INSERT INTO inventory (item_name, total_stock, price) VALUES
('Shirt', 100, 20),
('Jeans', 80, 40),
('Sneakers', 50, 60),
('Jacket', 30, 80);